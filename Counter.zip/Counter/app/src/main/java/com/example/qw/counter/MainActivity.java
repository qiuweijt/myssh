package com.example.qw.counter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button buttonAC,buttonDEL,buttonSin,buttonCos,buttonTan,buttonBaiFen,buttonGen,buttonSum,buttonJian,buttonCheng,buttonChu,buttonPoint,buttonEnd;
    Button button0,button1,button2,button3,button4,button5,button6,button7,button8,button9;
    EditText input;
    DecimalFormat df = new DecimalFormat("0.000000");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonAC = (Button)findViewById(R.id.AC);
        buttonDEL = (Button)findViewById(R.id.DEL);
        buttonSin = (Button)findViewById(R.id.SIN);
        buttonCos = (Button)findViewById(R.id.COS);
        buttonTan = (Button)findViewById(R.id.TAN);
        buttonBaiFen = (Button)findViewById(R.id.BaiFen);
        buttonGen = (Button)findViewById(R.id.Gen);
        buttonSum = (Button)findViewById(R.id.Sum);
        buttonJian = (Button)findViewById(R.id.Jian);
        buttonCheng = (Button)findViewById(R.id.Cheng);
        buttonChu = (Button)findViewById(R.id.Chu);
        buttonPoint = (Button)findViewById(R.id.Point);
        buttonEnd = (Button)findViewById(R.id.End);
        button0 = (Button)findViewById(R.id.Num0);
        button1 = (Button)findViewById(R.id.Num1);
        button2 = (Button)findViewById(R.id.Num2);
        button3 = (Button)findViewById(R.id.Num3);
        button4 = (Button)findViewById(R.id.Num4);
        button5 = (Button)findViewById(R.id.Num5);
        button6 = (Button)findViewById(R.id.Num6);
        button7 = (Button)findViewById(R.id.Num7);
        button8 = (Button)findViewById(R.id.Num8);
        button9 = (Button)findViewById(R.id.Num9);
        input = (EditText)findViewById(R.id.input);

        buttonAC.setOnClickListener(this);
        buttonDEL.setOnClickListener(this);
        buttonSin.setOnClickListener(this);
        buttonCos.setOnClickListener(this);
        buttonTan.setOnClickListener(this);
        buttonBaiFen.setOnClickListener(this);
        buttonGen.setOnClickListener(this);
        buttonSum.setOnClickListener(this);
        buttonJian.setOnClickListener(this);
        buttonCheng.setOnClickListener(this);
        buttonChu.setOnClickListener(this);
        buttonPoint.setOnClickListener(this);
        buttonEnd.setOnClickListener(this);
        button0.setOnClickListener(this);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        button6.setOnClickListener(this);
        button7.setOnClickListener(this);
        button8.setOnClickListener(this);
        button9.setOnClickListener(this);
    }

    @Override
    public void onClick(View v){
        String str = input.getText().toString();
        switch (v.getId()){
            case R.id.Num0:
            case R.id.Num1:
            case R.id.Num2:
            case R.id.Num3:
            case R.id.Num4:
            case R.id.Num5:
            case R.id.Num6:
            case R.id.Num7:
            case R.id.Num8:
            case R.id.Num9:
            case R.id.Point:
                input.setText(str + ((Button)v).getText());
                break;
            case R.id.SIN:
                if(!str.contains("+")&&!str.contains("-")&&!str.contains("*")&&!str.contains("/")){
                    double num = Double.parseDouble(str);
                    num = Math.sin(num * Math.PI/180);
                    input.setText(df.format(num) + "");
                }
                else if(str.contains("+")||str.contains("-")||str.contains("*")||str.contains("/")){
                    String string = str.substring(0,str.indexOf(" ")+2);
                    String other = string.substring( str.indexOf("")+3);
                    double num = Double.parseDouble(other);
                    num = Math.sin(num * Math.PI / 180);
                    input.setText(string + df.format(num));
                }
                break;
            case R.id.COS:
                if(!str.contains("+")&&!str.contains("-")&&!str.contains("*")&&!str.contains("/")){
                    double num = Double.parseDouble(str);
                    num = Math.cos(num * Math.PI/180);
                    input.setText(df.format(num) + "");
                }
                else if(str.contains("+")||str.contains("-")||str.contains("*")||str.contains("/")){
                    String string = str.substring(0,str.indexOf(" ")+2);
                    String other = str.substring( str.indexOf("")+3);
                    double num = Double.parseDouble(other);
                    num = Math.cos(num * Math.PI / 180);
                    input.setText(string + df.format(num));
                }
                break;
            case R.id.TAN:
               if(!str.contains("+")&&!str.contains("-")&&!str.contains("*")&&!str.contains("/")){
                    double num = Double.parseDouble(str);
                    num = Math.tan(num * Math.PI/180);
                    input.setText(df.format(num) + "");
                }
                else if(str.contains("+")||str.contains("-")||str.contains("*")||str.contains("/")){
                    String string = str.substring(0,str.indexOf(" ")+2);
                    String other = str.substring( str.indexOf("")+3);
                    double num = Double.parseDouble(other);
                    num = Math.tan(num * Math.PI / 180);
                    input.setText(string + df.format(num));
                }
                break;
            case R.id.BaiFen:
                if(!str.contains("+")&&!str.contains("-")&&!str.contains("*")&&!str.contains("/")){
                    double num = Double.parseDouble(str);
                    num = 0.01*num;
                    input.setText(df.format(num) + "");
                }
                else if(str.contains("+")||str.contains("-")||str.contains("*")||str.contains("/")){
                    String string = str.substring(0,str.indexOf(" ")+2);
                    String other = str.substring( str.indexOf("")+3);
                    double num = Double.parseDouble(other);
                    num = 0.01*num;
                    input.setText(string + df.format(num));
                }
                break;
            case R.id.Gen:
                if(!str.contains("+")&&!str.contains("-")&&!str.contains("*")&&!str.contains("/")){
                    double num = Double.parseDouble(str);
                    num = Math.sqrt(num);
                    input.setText(df.format(num) + "");
                }
                else if(str.contains("+")||str.contains("-")||str.contains("*")||str.contains("/")){
                    String string = str.substring(0,str.indexOf(" ")+2);
                    String other = str.substring( str.indexOf("")+3);
                    double num = Double.parseDouble(other);
                    num = Math.sqrt(num);
                    input.setText(string + df.format(num));
                }
                break;
            case R.id.Sum:
            case R.id.Jian:
            case R.id.Cheng:
            case R.id.Chu:
                if (str.contains("+") || str.contains("-") || str.contains("*") || str.contains("/")) {
                    str = str.substring(0,str.indexOf(""));
                }
                input.setText(str + " " + ((Button)v).getText()+" ");
                break;
            case R.id.AC:
                str = "";
                input.setText("");
                break;
            case R.id.DEL:
                if (str != null && !str.equals("")) {
                    input.setText(str.substring(0, str.length() - 1));
                }
                break;
            case R.id.End:
                getResult();
                break;
        }
    }
    private void getResult() {
        String text = input.getText().toString();
        if (text == null || text.equals("")) {
            return;
        }
        if (!text.contains(" ")) {
            return;
        }
        String Num1 = text.substring(0, text.indexOf(" "));
        String FuHao = text.substring(text.indexOf(" ") + 1, text.indexOf(" ") + 2);
        String Num2 = text.substring(text.indexOf(" ") + 3);
        if (!text.contains("SIN")||!text.contains("COS")||!text.contains("TAN")||!text.contains("%")||!text.contains("√")) {
            double end = 0;
            double Number1 = Double.parseDouble(Num1);
            double Number2 = Double.parseDouble(Num2);
            if (FuHao.equals("+")) {
                end = Number1 + Number2;
            }
            if (FuHao.equals("-")) {
                end = Number1 - Number2;
            }
            if (FuHao.equals("*")) {
                end = Number1 * Number2;
            }
            if (FuHao.equals("/")) {
                if (Number2 == 0) end = 0;
                else end = Number1 / Number2;
            }
            if (!Num1.contains(".") && !Num2.contains(".") && !FuHao.equals("/")) {
                int res = (int) end;
                input.setText(res + "");
            } else {
                input.setText(df.format(end )+ "");
            }
        }
    }
}

