package com.example.qw.note2;


import java.text.SimpleDateFormat;
import java.util.Date;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class noteEdit extends Activity {
    private TextView tv_date;
    private EditText et_content;
    private Button btn_ok;
    private Button btn_cancel;
    private NotesDB DB;
    private SQLiteDatabase dbread;
    public static int ENTER_STATE = 0;
    public static String last_content;
    public static String Odate;
    public static String scContent;
    public static String scContent1;
    public static String scDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        // 设置无标题
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.content_note_edit);

        tv_date = (TextView) findViewById(R.id.tv_date);
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateString = sdf.format(date);
        tv_date.setText(dateString);

        et_content = (EditText) findViewById(R.id.et_content);
        DB = new NotesDB(this);
        dbread = DB.getReadableDatabase();

        Intent intent = getIntent();
        last_content = intent.getStringExtra("content");
        Odate = intent.getStringExtra("date");
        scContent = intent.getStringExtra("scContent");
        String sql = "select *from note4 where content like ? order by content desc";
        Cursor c = dbread.rawQuery(sql,new String[]{"%" +scContent+ "%"});
        while (c.moveToNext()){
            scContent1 = c.getString(c.getColumnIndex("content"));
            scDate = c.getString(c.getColumnIndex("date"));
        }
        if(ENTER_STATE == 1) {
            et_content.setText(last_content);
        }
        else if(ENTER_STATE == 2){
            et_content.setText(scContent1);
        }
        // 确认按钮的点击事件
        btn_ok = (Button) findViewById(R.id.btn_ok);
        btn_ok.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                // 获取日志内容
                String content = et_content.getText().toString();
                Log.d("LOG1", content);
                // 获取写日志时间
                Date date = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String dateNum = sdf.format(date);
                // 添加一个新的日志
                if (ENTER_STATE == 0) {
                    if (!content.equals("")) {
                        String sql = "insert into " + NotesDB.TABLE_NAME_NOTES
                                + " values('" + content + "'" + "," + "'" + dateNum + "')";
                        dbread.execSQL(sql);
                    }
                }
                // 查看并修改一个已有的日志
                else if(ENTER_STATE == 1){
                    String updatesql = "update note4 set content ='"
                            + content + "',date = '" + dateNum + "' where date = ?";
                    dbread.execSQL(updatesql,new String[]{Odate});
                }
                //查找并修改一个已有日志
                else if(ENTER_STATE == 2){
                    String updatesql = "update note4 set content ='"
                            + content + "',date = '" + dateNum + "' where date = ?";
                    dbread.execSQL(updatesql,new String[]{scDate});
                }
                Intent data = new Intent();
                setResult(2, data);
               finish();
            }
        });
        btn_cancel = (Button) findViewById(R.id.btn_cancel);
        btn_cancel.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                Intent intent = new Intent(noteEdit.this,MainActivity.class);
                finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
    }
}





