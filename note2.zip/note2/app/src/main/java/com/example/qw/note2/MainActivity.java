package com.example.qw.note2;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements
        OnItemClickListener, OnItemLongClickListener {

    private Context mContext;
    private ListView listview;
    private EditText editText;
    private static String searchMsg;
    private SimpleAdapter simp_adapter;
    private List<Map<String, Object>> dataList;
    private Button addNote;
    private Button search;
    private NotesDB DB;
    private SQLiteDatabase dbread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        listview = (ListView) findViewById(R.id.listview);
        editText = (EditText)findViewById(R.id.scMsg);
        dataList = new ArrayList<Map<String, Object>>();
        search = (Button)findViewById(R.id.search);
        addNote = (Button) findViewById(R.id.btn_addNote);
        mContext = this;
        addNote.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                noteEdit.ENTER_STATE = 0;
                Intent intent = new Intent(mContext, noteEdit.class);
                startActivityForResult(intent, 1);
            }
        });

        DB = new NotesDB(this);
        dbread = DB.getReadableDatabase();
        RefreshNotesList();

        search.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
//                if(searchMsg!=null) {
//                    Toast.makeText(getApplicationContext(), "不为空", Toast.LENGTH_LONG).show();
//                }
//                else{
//                    Toast.makeText(getApplicationContext(), "为空", Toast.LENGTH_LONG).show();
//                }
                noteEdit.ENTER_STATE = 2;
                searchMsg = editText.getText().toString();
                Intent intent1 = new Intent();
                intent1.putExtra("scContent",searchMsg);
                intent1.setClass(MainActivity.this, noteEdit.class);
                startActivityForResult(intent1, 1);
            }
        });

        listview.setOnItemClickListener(this);
        listview.setOnItemLongClickListener(this);
    }


    public void RefreshNotesList() {

        int size = dataList.size();
        if (size > 0) {
            dataList.removeAll(dataList);
            simp_adapter.notifyDataSetChanged();
            listview.setAdapter(simp_adapter);
        }
        simp_adapter = new SimpleAdapter(this, getData(), R.layout.item,
                new String[] { "tv_content", "tv_date" }, new int[] {
                R.id.tv_content, R.id.tv_date });
        listview.setAdapter(simp_adapter);
    }

    private List<Map<String, Object>> getData() {

        Cursor cursor = dbread.query("note4", null, "content!=\"\"", null, null,
                null, null);

        while (cursor.moveToNext()) {
            String content = cursor.getString(cursor.getColumnIndex("content"));
            String date = cursor.getString(cursor.getColumnIndex("date"));
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("tv_content", content);
            map.put("tv_date", date);
            dataList.add(map);
        }
        cursor.close();
        return dataList;

    }


    // 点击listview中某一项的监听事件
    @Override
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
        noteEdit.ENTER_STATE = 1;
        final int n = arg2;
        String sql = "select *from note4";
        Cursor c = dbread.rawQuery(sql,null);
        c.moveToPosition(n);
        String date = c.getString(c.getColumnIndex("date"));
        String content = c.getString(c.getColumnIndex("content"));
        c.close();
        Log.d("TEXT", date);
        Intent myIntent = new Intent();
        myIntent.putExtra("content",content);
        myIntent.putExtra("date",date);
        myIntent.setClass(MainActivity.this, noteEdit.class);
        startActivityForResult(myIntent, 1);
    }

    @Override
    // 接受上一个页面返回的数据，并刷新页面
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == 2) {
            RefreshNotesList();
        }
    }

    // 点击listview中某一项长时间的点击事件
    @Override
    public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int arg2,
                                   long arg3) {
        final int n=arg2;
        Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("删除该日志");
        builder.setMessage("确认删除吗？");
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String sql = "select date from note4";
                Cursor c = dbread.rawQuery(sql,null);
                c.moveToPosition(n);
                String date = c.getString(c.getColumnIndex("date"));
                c.close();
                String sql_del = "delete from note4 where date= ?";
                dbread.execSQL(sql_del,new String[]{date});
                RefreshNotesList();

            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        builder.create();
        builder.show();
        return true;
    }

}


